import { Author } from '@/types/author'
import authorsData from '@/data/authors.json'

export async function getAllAuthors(): Promise<Author[]> {
  return authorsData.authors
}

export async function getActiveAuthors(): Promise<Author[]> {
  return authorsData.authors.filter(author => author.active)
}

export async function getAuthorBySlug(slug: string): Promise<Author | null> {
  return authorsData.authors.find(author => author.slug === slug) || null
}

export async function getAuthorsByRole(role: string): Promise<Author[]> {
  return authorsData.authors.filter(author => author.role === role)
}

export async function getFeaturedAuthors(limit: number = 8): Promise<Author[]> {
  return authorsData.authors
    .filter(author => author.active)
    .slice(0, limit)
}
