import { format, formatDistanceToNow, parseISO } from 'date-fns'
import { tr } from 'date-fns/locale'

type DateFormat = 'short' | 'long' | 'full' | string

export function formatDate(dateString: string, formatType: DateFormat = 'long'): string {
  const date = parseISO(dateString)
  
  const formatStrings: Record<string, string> = {
    short: 'd MMM yyyy',
    long: 'd MMMM yyyy',
    full: 'EEEE, d MMMM yyyy',
  }
  
  const formatStr = formatStrings[formatType] || formatType
  
  return format(date, formatStr, { locale: tr })
}

export function getRelativeTime(dateString: string): string {
  return formatDistanceToNow(parseISO(dateString), { 
    addSuffix: true,
    locale: tr 
  })
}

export function getMonthYear(dateString: string): string {
  return format(parseISO(dateString), 'MMMM yyyy', { locale: tr })
}
