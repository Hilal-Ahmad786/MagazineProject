# Mazhar Dergisi - Bonus Özellikler

Bu paket 4 bonus özellik içerir:

1. **PDF Okuyucu** - Sayıları sitede okuma
2. **İstatistikler Dashboard** - Okuma takibi
3. **Çoklu Dil (EN/TR)** - i18n desteği
4. **PWA** - Offline okuma, uygulama yükleme

---

## 📁 DOSYA YAPISI

```
src/
├── app/
│   ├── oku/[issueId]/
│   │   ├── page.tsx              ← PDF okuyucu sayfası
│   │   └── PDFReaderClient.tsx
│   ├── dashboard/
│   │   ├── page.tsx              ← İstatistikler sayfası
│   │   └── DashboardClient.tsx
│   └── offline/
│       └── page.tsx              ← Çevrimdışı sayfası
├── components/
│   ├── Providers.tsx             ← TÜM PROVIDERS
│   ├── pdf/
│   │   ├── PDFViewer.tsx
│   │   ├── PDFModal.tsx
│   │   └── index.ts
│   ├── dashboard/
│   │   ├── StatsCard.tsx
│   │   ├── ViewsChart.tsx
│   │   ├── TopArticles.tsx
│   │   └── index.ts
│   ├── language/
│   │   ├── LanguageSwitcher.tsx
│   │   └── index.ts
│   └── pwa/
│       ├── PWARegister.tsx
│       ├── InstallPrompt.tsx
│       └── index.ts
├── contexts/
│   ├── AnalyticsContext.tsx
│   └── LanguageContext.tsx
├── hooks/
│   ├── useReadingTracker.ts
│   └── usePWA.ts
└── lib/
    └── i18n/
        └── translations.ts
public/
├── manifest.json
└── sw.js
```

---

## 🔧 KURULUM

### 1. Paketleri Yükleyin

```bash
npm install react-pdf
```

### 2. Dosyaları Kopyalayın

Tüm klasörleri projenize kopyalayın.

### 3. layout.tsx'e PWA Ekleyin

```tsx
import { PWARegister } from '@/components/pwa'
import { InstallPrompt } from '@/components/pwa'

export default function RootLayout({ children }) {
  return (
    <html>
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#facc15" />
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
      </head>
      <body>
        <Providers>
          {children}
          <PWARegister />
          <InstallPrompt />
        </Providers>
      </body>
    </html>
  )
}
```

### 4. PWA İkonlarını Oluşturun

`public/icons/` klasörüne şu boyutlarda ikonlar ekleyin:
- 72x72, 96x96, 128x128, 144x144, 152x152, 192x192, 384x384, 512x512

---

## 📖 KULLANIM

### 1. PDF Okuyucu

Sayfa: `/oku/[issueId]`

Sayı detay sayfasına link ekleyin:
```tsx
<Link href={`/oku/${issue.id}`}>
  Online Oku
</Link>
```

Modal olarak kullanım:
```tsx
import { PDFModal } from '@/components/pdf'

<PDFModal
  url="/pdfs/sayi-1.pdf"
  title="Sayı 1: Gurbet"
  isOpen={isOpen}
  onClose={() => setIsOpen(false)}
/>
```

### 2. İstatistikler Dashboard

Sayfa: `/dashboard`

Yazı sayfalarında okuma takibi:
```tsx
import { useReadingTracker } from '@/hooks/useReadingTracker'

export default function ArticlePage({ article }) {
  useReadingTracker(article.id)
  
  return <article>...</article>
}
```

### 3. Çoklu Dil

Header'a dil değiştirici ekleyin:
```tsx
import { LanguageSwitcher } from '@/components/language'

<LanguageSwitcher variant="dropdown" />
```

Çevirileri kullanın:
```tsx
import { useTranslation } from '@/contexts/LanguageContext'

function MyComponent() {
  const { t } = useTranslation()
  
  return <h1>{t('nav.home')}</h1>
}
```

### 4. PWA

Otomatik çalışır:
- Service Worker kayıt edilir
- Offline cache aktif
- 30 saniye sonra yükleme istemi gösterilir

Manuel kontrol:
```tsx
import { usePWA } from '@/hooks/usePWA'

function MyComponent() {
  const { isInstallable, isOnline, install } = usePWA()
  
  return (
    <>
      {!isOnline && <OfflineBanner />}
      {isInstallable && <button onClick={install}>Yükle</button>}
    </>
  )
}
```

---

## 🎨 SAYFA ÖNİZLEMELERİ

### PDF Okuyucu
```
┌──────────────────────────────────────────────────┐
│ ✕  Sayı 1: Gurbet     ◀ 3/24 ▶     - 100% +  ⬇  │
├──────────────────────────────────────────────────┤
│                                                  │
│              ┌──────────────────┐                │
│              │                  │                │
│              │    PDF PAGE      │                │
│              │                  │                │
│              │                  │                │
│              └──────────────────┘                │
│                                                  │
├──────────────────────────────────────────────────┤
│ [1] [2] [3] [4] [5] [6] [7] [8] ...              │
└──────────────────────────────────────────────────┘
```

### Dashboard
```
┌─────────────────────────────────────────────────────┐
│  OKUMA İSTATİSTİKLERİM                              │
├─────────────────────────────────────────────────────┤
│ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐│
│ │  👁️ 142   │ │  📄 28   │ │ ⏱️ 4sa   │ │ ⏱️ 8dk   ││
│ │  Views   │ │ Articles │ │ Total    │ │ Average  ││
│ └──────────┘ └──────────┘ └──────────┘ └──────────┘│
├─────────────────────────────────────────────────────┤
│ [Chart: Daily Views]     │ [Top 5 Articles]        │
└─────────────────────────────────────────────────────┘
```

---

## 🧪 TEST

```bash
npm run dev

# Test URL'leri:
http://localhost:3000/oku/1        → PDF Okuyucu
http://localhost:3000/dashboard    → İstatistikler
http://localhost:3000/offline      → Çevrimdışı sayfa

# PWA testi için HTTPS gerekli (production'da)
```

---

## ⚠️ NOTLAR

1. **react-pdf**: PDF görüntüleyici için gerekli
2. **PWA**: HTTPS gerektirir (localhost hariç)
3. **Icons**: PWA ikonlarını oluşturmanız gerekli
4. **Çeviriler**: `translations.ts` dosyasını genişletebilirsiniz
5. **Analytics**: localStorage kullanır (backend gerekmez)
