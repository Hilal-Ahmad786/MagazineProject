'use client'

import { PDFViewer } from '@/components/pdf/PDFViewer'
import { useRouter } from 'next/navigation'

interface PDFReaderClientProps {
  pdfUrl: string
  title: string
  issueId: string
}

export function PDFReaderClient({ pdfUrl, title, issueId }: PDFReaderClientProps) {
  const router = useRouter()

  const handleClose = () => {
    router.push(`/sayilar/${issueId}`)
  }

  return (
    <div className="h-screen">
      <PDFViewer url={pdfUrl} title={title} onClose={handleClose} />
    </div>
  )
}
