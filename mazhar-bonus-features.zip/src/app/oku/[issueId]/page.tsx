import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { getIssueById, getAllIssues } from '@/lib/data/issues'
import { PDFReaderClient } from './PDFReaderClient'

interface Props {
  params: { issueId: string }
}

export async function generateStaticParams() {
  const issues = await getAllIssues()
  return issues.map(issue => ({ issueId: issue.id }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const issue = await getIssueById(params.issueId)
  
  if (!issue) {
    return { title: 'Sayı Bulunamadı | Mazhar Dergisi' }
  }

  return {
    title: `Sayı ${issue.number}: ${issue.theme} - Oku | Mazhar Dergisi`,
    description: `Mazhar Dergisi ${issue.number}. sayısını online okuyun.`,
  }
}

export default async function PDFReaderPage({ params }: Props) {
  const issue = await getIssueById(params.issueId)

  if (!issue || !issue.pdfUrl) {
    notFound()
  }

  return (
    <main className="min-h-screen bg-gray-900">
      <PDFReaderClient 
        pdfUrl={issue.pdfUrl} 
        title={`Sayı ${issue.number}: ${issue.theme}`}
        issueId={issue.id}
      />
    </main>
  )
}
