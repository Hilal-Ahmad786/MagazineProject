'use client'

import { useRouter } from 'next/navigation'
import { PDFViewer } from '@/components/pdf/PDFViewer'

interface PDFReaderClientProps {
  pdfUrl: string
  title: string
  issueId: string
}

export function PDFReaderClient({ pdfUrl, title, issueId }: PDFReaderClientProps) {
  const router = useRouter()

  const handleClose = () => {
    router.push(`/sayilar/${issueId}`)
  }

  return (
    <PDFViewer 
      url={pdfUrl}
      title={title}
      onClose={handleClose}
    />
  )
}
