'use client'

import { ReactNode } from 'react'
import { SearchProvider } from '@/contexts/SearchContext'
import { ThemeProvider } from '@/contexts/ThemeContext'
import { ReadingListProvider } from '@/contexts/ReadingListContext'
import { CommentsProvider } from '@/contexts/CommentsContext'
import { AnalyticsProvider } from '@/contexts/AnalyticsContext'
import { LanguageProvider } from '@/contexts/LanguageContext'

interface ProvidersProps {
  children: ReactNode
}

export function Providers({ children }: ProvidersProps) {
  return (
    <LanguageProvider>
      <ThemeProvider>
        <AnalyticsProvider>
          <SearchProvider>
            <ReadingListProvider>
              <CommentsProvider>
                {children}
              </CommentsProvider>
            </ReadingListProvider>
          </SearchProvider>
        </AnalyticsProvider>
      </ThemeProvider>
    </LanguageProvider>
  )
}
