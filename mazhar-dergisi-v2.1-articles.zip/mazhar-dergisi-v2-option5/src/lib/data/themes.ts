import { Theme } from '@/types/theme'
import themesData from '@/data/themes.json'

export async function getAllThemes(): Promise<Theme[]> {
  return themesData.themes
}

export async function getActiveThemes(): Promise<Theme[]> {
  return themesData.themes.filter(theme => theme.active)
}

export async function getThemeBySlug(slug: string): Promise<Theme | null> {
  return themesData.themes.find(theme => theme.slug === slug) || null
}

export async function getPopularThemes(limit: number = 8): Promise<Theme[]> {
  return themesData.themes
    .filter(theme => theme.active)
    .slice(0, limit)
}
