'use client'

import Link from 'next/link'
import { Navbar } from './Navbar'
import { useState } from 'react'

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
      <div 
        className="px-8 md:px-12 py-6"
        style={{
          background: isScrolled 
            ? 'rgba(0, 0, 0, 0.95)' 
            : 'linear-gradient(to bottom, rgba(0,0,0,0.9), transparent)'
        }}
      >
        <div className="max-w-[1600px] mx-auto flex items-center justify-between">
          <Link 
            href="/" 
            className="text-3xl md:text-4xl font-black text-yellow-400 tracking-tight hover:text-yellow-300 transition-colors"
          >
            MAZHAR.
          </Link>

          <Navbar />

          <div className="flex items-center gap-4">
            <button 
              className="text-white hover:text-yellow-400 transition-colors"
              aria-label="Search"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
