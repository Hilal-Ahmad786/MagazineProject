# Mazhar Dergisi v2 - Reading List System

Slide-in drawer, bookmark butonları ve localStorage persistence ile okuma listesi sistemi.

## 📦 İçerik

```
src/components/reading-list/
├── ReadingListButton.tsx  # Makale kaydet butonu (3 varyant)
├── ReadingListToggle.tsx  # Header toggle butonu (badge ile)
├── ReadingListDrawer.tsx  # Slide-in panel
├── ReadingListItem.tsx    # Drawer içindeki item
└── index.ts               # Merkezi export
```

## 🔌 Bağımlılıklar

Bu paket **Foundation Package** gerektirir:
- `ReadingListContext` from `@/contexts`
- `cn`, `getRelativeTime` from `@/lib/utils`
- `ReadingListItem`, `Article` types from `@/types`

## 🚀 Kurulum

1. Foundation paketinin kurulu olduğundan emin olun
2. `src/components/reading-list/` klasörünü projenize kopyalayın

## 📝 Kullanım

### 1. Layout'a Drawer Ekleyin

```tsx
// src/app/layout.tsx
import { Providers } from '@/components/Providers'
import { ReadingListDrawer } from '@/components/reading-list'

export default function RootLayout({ children }) {
  return (
    <html lang="tr" className="dark">
      <body>
        <Providers>
          {children}
          <ReadingListDrawer />
        </Providers>
      </body>
    </html>
  )
}
```

### 2. Header'a Toggle Ekleyin

```tsx
// src/components/Header.tsx
import { ReadingListToggle } from '@/components/reading-list'

export function Header() {
  return (
    <header>
      <nav className="flex items-center gap-4">
        {/* ... */}
        <ReadingListToggle variant="icon" showCount />
      </nav>
    </header>
  )
}
```

### 3. Makale Kartında/Sayfasında Kaydet Butonu

```tsx
// src/components/ArticleCard.tsx
import { ReadingListButton } from '@/components/reading-list'

export function ArticleCard({ article }) {
  return (
    <div className="article-card">
      {/* ... */}
      <ReadingListButton 
        article={article} 
        variant="icon" 
        size="sm" 
      />
    </div>
  )
}

// src/app/yazilar/[slug]/page.tsx
import { ReadingListButton } from '@/components/reading-list'

export default function ArticlePage({ article }) {
  return (
    <article>
      <header>
        <h1>{article.title}</h1>
        <ReadingListButton 
          article={article} 
          variant="button" 
          size="md" 
        />
      </header>
      {/* ... */}
    </article>
  )
}
```

## 🎨 Component API

### ReadingListButton

| Prop | Type | Default | Açıklama |
|------|------|---------|----------|
| `article` | `Article` | required | Makale verisi |
| `variant` | `'icon' \| 'button' \| 'minimal'` | `'button'` | Görünüm |
| `size` | `'sm' \| 'md' \| 'lg'` | `'md'` | Boyut |
| `showLabel` | `boolean` | `true` | Etiket göster |

### ReadingListToggle

| Prop | Type | Default | Açıklama |
|------|------|---------|----------|
| `variant` | `'icon' \| 'button'` | `'icon'` | Görünüm |
| `size` | `'sm' \| 'md' \| 'lg'` | `'md'` | Boyut |
| `showCount` | `boolean` | `true` | Sayı badge göster |

### ReadingListDrawer

| Prop | Type | Default | Açıklama |
|------|------|---------|----------|
| `className` | `string` | - | Ek CSS sınıfları |

### ReadingListItem

| Prop | Type | Default | Açıklama |
|------|------|---------|----------|
| `item` | `ReadingListItem` | required | Item verisi |
| `onRemove` | `(articleId) => void` | required | Silme handler |
| `onClick` | `() => void` | - | Tıklama handler |

## 🎯 Özellikler

- ✅ Slide-in drawer (sağdan)
- ✅ Animated transitions
- ✅ Badge ile sayı gösterimi
- ✅ localStorage persistence
- ✅ Hover'da silme butonu
- ✅ Empty state
- ✅ Tümünü temizle
- ✅ ESC ile kapatma
- ✅ Backdrop click kapatma
- ✅ 3 farklı buton varyantı
- ✅ Responsive design

## 💾 Data Structure

```typescript
interface ReadingListItem {
  id: string
  articleId: string
  title: string
  author: string
  image: string
  slug: string
  addedAt: string // ISO date
}
```

## 🔧 localStorage

Okuma listesi `mazhar_reading_list` key'i altında saklanır:

```json
[
  {
    "id": "abc123",
    "articleId": "article-1",
    "title": "Örnek Yazı Başlığı",
    "author": "Yazar Adı",
    "image": "/images/article.jpg",
    "slug": "ornek-yazi",
    "addedAt": "2024-12-09T10:00:00Z"
  }
]
```

## 📐 Varyant Örnekleri

### ReadingListButton Varyantları

```tsx
// Icon only (kartlar için)
<ReadingListButton article={article} variant="icon" size="sm" />

// Full button (makale sayfası için)
<ReadingListButton article={article} variant="button" size="md" />

// Minimal (inline kullanım)
<ReadingListButton article={article} variant="minimal" />
```

### ReadingListToggle Varyantları

```tsx
// Icon with badge (header için)
<ReadingListToggle variant="icon" showCount />

// Full button
<ReadingListToggle variant="button" showCount />
```

## 🔗 İlgili Dosyalar

- `@/contexts/ReadingListContext.tsx` - State yönetimi
- `@/types/index.ts` - ReadingListItem type
- `@/lib/constants.ts` - Storage keys, max items

---

**Version:** 2.9.0-readinglist
**Date:** December 2024
