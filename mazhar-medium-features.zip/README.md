# Mazhar Dergisi - Orta Öncelikli Özellikler

Bu paket 4 özellik içerir:

1. **Yazar Başvuru Formu** - `/yazar-ol` sayfası
2. **İletişim Sayfası** - `/iletisim` Form + harita
3. **RSS Feed** - `/feed` ve `/feed.json`
4. **Dinamik OG Images** - `/api/og`

---

## 📁 DOSYA YAPISI

```
src/
├── app/
│   ├── yazar-ol/
│   │   └── page.tsx              ← Yazar başvuru sayfası
│   ├── iletisim/
│   │   └── page.tsx              ← İletişim sayfası
│   ├── feed/
│   │   └── route.ts              ← RSS Feed (XML)
│   ├── feed.json/
│   │   └── route.ts              ← JSON Feed
│   └── api/
│       ├── author-application/
│       │   └── route.ts          ← Başvuru API
│       ├── contact/
│       │   └── route.ts          ← İletişim API
│       └── og/
│           └── route.tsx         ← Dinamik OG Image
├── components/
│   └── forms/
│       ├── AuthorApplicationForm.tsx
│       ├── ContactForm.tsx
│       └── index.ts
└── lib/
    └── utils/
        └── og.ts                 ← OG URL helper
```

---

## 🔧 KURULUM

### 1. Dosyaları Kopyalayın

Tüm klasörleri projenize kopyalayın.

### 2. Routes.ts'e Ekleyin

```typescript
// src/lib/constants/routes.ts
export const ROUTES = {
  // ... mevcut route'lar
  GUEST_AUTHOR: '/yazar-ol',
  CONTACT: '/iletisim',
  RSS_FEED: '/feed',
}
```

### 3. .env.local Ayarlayın

```env
# Site URL (OG images için)
NEXT_PUBLIC_SITE_URL=https://mazhardergisi.com

# E-posta servisi (Resend)
RESEND_API_KEY=re_xxxxx
NOTIFICATION_EMAIL=editor@mazhardergisi.com
```

### 4. Header/Footer'a Link Ekleyin

```tsx
// RSS icon for header/footer
<a href="/feed" target="_blank" rel="noopener noreferrer">
  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
    <path d="M6.18 15.64a2.18 2.18 0 0 1 2.18 2.18C8.36 19 7.38 20 6.18 20C5 20 4 19 4 17.82a2.18 2.18 0 0 1 2.18-2.18M4 4.44A15.56 15.56 0 0 1 19.56 20h-2.83A12.73 12.73 0 0 0 4 7.27V4.44m0 5.66a9.9 9.9 0 0 1 9.9 9.9h-2.83A7.07 7.07 0 0 0 4 12.93V10.1Z"/>
  </svg>
</a>
```

---

## 📖 KULLANIM

### 1. Yazar Başvuru Formu

Sayfa: `/yazar-ol`

Özellikler:
- Ad, e-posta, telefon, meslek
- Kısa biyografi
- İlgi alanları (çoklu seçim)
- Örnek yazı
- Portfolyo linki
- Motivasyon metni
- FAQ bölümü

### 2. İletişim Sayfası

Sayfa: `/iletisim`

Özellikler:
- İletişim bilgileri
- Sosyal medya linkleri
- Harita placeholder
- İletişim formu (konu seçimi)
- Otomatik yanıt e-postası

### 3. RSS Feed

```
XML: https://mazhardergisi.com/feed
JSON: https://mazhardergisi.com/feed.json
```

Son 20 yazıyı içerir. 1 saat cache'lenir.

### 4. Dinamik OG Images

URL formatı:
```
/api/og?title=...&subtitle=...&author=...&theme=...&type=article
```

Sayfa metadata'sında kullanım:
```tsx
import { getOGImageUrl } from '@/lib/utils/og'

export async function generateMetadata({ params }): Promise<Metadata> {
  const article = await getArticleBySlug(params.slug)
  
  return {
    title: article.title,
    openGraph: {
      images: [
        {
          url: getOGImageUrl({
            title: article.title,
            subtitle: article.subtitle,
            author: article.author?.fullName,
            theme: article.themes?.[0],
            type: 'article',
          }),
          width: 1200,
          height: 630,
        },
      ],
    },
  }
}
```

---

## 🧪 TEST

```bash
npm run dev

# Test URL'leri:
http://localhost:3000/yazar-ol
http://localhost:3000/iletisim
http://localhost:3000/feed
http://localhost:3000/feed.json
http://localhost:3000/api/og?title=Test&theme=Gurbet
```

---

## 🎨 OG IMAGE ÖNİZLEME

```
┌────────────────────────────────────────────────────────┐
│  MAZHAR.                                    [GURBET]   │
│                                                        │
│                                                        │
│  YAZI BAŞLIĞI BURADA                                  │
│  GÖRÜNECEK                                            │
│                                                        │
│  Alt başlık veya excerpt metni                        │
│                                                        │
│                                                        │
│  ─────────────────────────────────────────────────    │
│  (A) Yazar Adı              mazhardergisi.com         │
└────────────────────────────────────────────────────────┘
```

---

## ⚠️ NOTLAR

1. **E-posta**: Resend.com kullanılıyor (ücretsiz 100 email/gün)
2. **OG Images**: Edge runtime kullanıyor (Vercel'de otomatik)
3. **RSS**: XML ve JSON formatları destekleniyor
4. **Cache**: Feed'ler 1 saat cache'leniyor
