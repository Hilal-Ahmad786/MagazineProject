'use client'

import { SearchProvider } from '@/contexts/SearchContext'
import { ReactNode } from 'react'

interface ProvidersProps {
  children: ReactNode
}

export function Providers({ children }: ProvidersProps) {
  return (
    <SearchProvider>
      {children}
    </SearchProvider>
  )
}
