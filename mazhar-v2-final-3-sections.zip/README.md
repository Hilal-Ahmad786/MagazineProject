# Mazhar Dergisi v2 - Final 3 Sections

Bu paket şu 3 bölümü içerir:
1. **Hakkımızda** sayfası
2. **Search Modal** (Fuse.js ile site içi arama)
3. **Mobile Menu** (Hamburger navigasyon)

---

## 📁 DOSYA YAPISI

```
src/
├── app/
│   ├── layout.tsx              ← DEĞİŞTİR (Providers eklenmiş)
│   └── hakkimizda/
│       ├── page.tsx            ← YENİ
│       └── loading.tsx         ← YENİ
├── components/
│   ├── Providers.tsx           ← YENİ
│   ├── layout/
│   │   ├── Header.tsx          ← DEĞİŞTİR
│   │   ├── MobileMenu.tsx      ← YENİ
│   │   └── index.ts            ← YENİ
│   └── search/
│       ├── SearchModal.tsx     ← YENİ
│       ├── SearchResults.tsx   ← YENİ
│       ├── SearchWrapper.tsx   ← YENİ
│       └── index.ts            ← YENİ
└── contexts/
    └── SearchContext.tsx       ← YENİ
```

---

## 🔧 KURULUM

### 1. Fuse.js Yükle
```bash
npm install fuse.js
```

### 2. Dosyaları Kopyala
- `src/app/hakkimizda/` klasörünü projenize kopyalayın
- `src/components/search/` klasörünü projenize kopyalayın
- `src/contexts/` klasörünü projenize kopyalayın
- `src/components/Providers.tsx` dosyasını kopyalayın

### 3. Mevcut Dosyaları Güncelle
- `src/app/layout.tsx` → Bu paketteki ile DEĞİŞTİRİN
- `src/components/layout/Header.tsx` → Bu paketteki ile DEĞİŞTİRİN
- `src/components/layout/MobileMenu.tsx` → Bu dosyayı EKLEYIN
- `src/components/layout/index.ts` → Bu dosyayı EKLEYIN veya güncelleyin

---

## ⚠️ ÖNEMLİ NOTLAR

1. **layout.tsx** dosyası `<Providers>` ve `<SearchWrapper>` ile sarılmış durumda
2. **Header.tsx** artık `useSearch()` hook'u ve `<MobileMenu />` kullanıyor
3. Search için `fuse.js` paketi gerekli
4. Tüm dosyalar mevcut data loaders'ı kullanıyor (`@/lib/data/...`)

---

## 🧪 TEST

```
npm run dev

# Test URL'leri:
http://localhost:3000/hakkimizda
http://localhost:3000 → ⌘K veya 🔍 tıkla → Search Modal
http://localhost:3000 → Mobilde (< 1024px) → ≡ hamburger tıkla
```
